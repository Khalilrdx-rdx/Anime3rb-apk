# Anime3rb Android

A simple Android WebView wrapper for https://anime3rb.com/.

The launcher icon uses the image supplied by the user. Build with JDK 17 and Gradle 8.9:
`gradle assembleDebug`

Note: some website features, downloads, uploads, or media players may require additional WebView integration and may not work identically to a full browser.
