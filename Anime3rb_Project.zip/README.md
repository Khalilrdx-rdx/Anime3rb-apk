# Anime3rb – Native Catalog Prototype

- Separate Android interface.
- Searches anime titles from the site's title catalogue (up to 12 paginated catalogue pages).
- Opens a title and reads its episode links.
- Opens the episode page inside the app.
- Blocks popup windows and external top-level ad redirects; blocks two ad hosts observed in public reports.
- Uses the user's supplied launcher icon.

Important limitations:
- The site does not provide a public API in this project. Catalog extraction depends on its current page structure and may need maintenance.
- This app does not extract protected direct media URLs, bypass membership requirements, or remove ads embedded in the site's own player.
- The site's IPTV information page states that IPTV playback requires a premium membership. Normal episode-page playback may still depend on the site's player and policies.

Build with JDK 17 and Gradle 8.9:
`gradle assembleDebug`
