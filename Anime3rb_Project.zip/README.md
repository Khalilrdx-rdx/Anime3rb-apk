# Anime3rb – New Android App

A new Android app shell with a native home screen and search over episode links publicly listed on Anime3rb's homepage. Episode pages are opened in an embedded WebView so the site itself handles its own player and account requirements.

The app does not extract direct media URLs, bypass site access controls, or download video files. The catalog may fail if the site blocks automated page access or changes its page structure.

Build with JDK 17 and Gradle 8.9:
`gradle assembleDebug`

Launcher icon: user-provided image.
