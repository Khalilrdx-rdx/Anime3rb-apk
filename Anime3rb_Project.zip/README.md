# Anime3rb Android

Android WebView wrapper for https://anime3rb.com/.

- Custom launcher icon supplied by the user.
- Handles `intent://` links and attempts to open their target app/browser.
- Opens other supported external URI schemes through Android.

Build with JDK 17 and Gradle 8.9:
`gradle assembleDebug`

Some website functions may still need additional WebView integration, such as file uploads, downloads, or site-specific media handling.
