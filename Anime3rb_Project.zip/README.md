# Anime3rb Android
A WebView wrapper for https://anime3rb.com/. The app requires an internet connection.
