package com.anime3rb.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import android.net.Uri
import android.content.Intent

class MainActivity : Activity() {
    private val bg = Color.rgb(20, 27, 40)
    private val panel = Color.rgb(35, 45, 62)
    private val accent = Color.rgb(125, 190, 85)

    private lateinit var root: LinearLayout
    private lateinit var search: EditText
    private lateinit var list: LinearLayout
    private lateinit var hiddenCatalog: WebView
    private lateinit var player: WebView
    private lateinit var titleBar: TextView

    private data class Entry(val title: String, val url: String)
    private val anime = mutableListOf<Entry>()
    private val episodes = mutableListOf<Entry>()
    private var catalogPage = 1
    private val maxCatalogPages = 12
    private var catalogMode = "anime"
    private var currentAnime = ""
    private var screen = "home"
    private var loading: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildHome()
        setupHiddenCatalog()
        loadCatalogPage(1)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun buildHome() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(16), dp(12), dp(16), dp(8))
        }
        titleBar = TextView(this).apply {
            text = "Anime3rb"
            textSize = 26f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(6), 0, dp(12))
        }
        root.addView(titleBar)

        search = EditText(this).apply {
            hint = "ابحث عن أنمي..."
            textSize = 15f
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            setPadding(dp(14), 0, dp(14), 0)
            background = rounded(panel, 14)
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    renderAnime(s?.toString().orEmpty())
                }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(50)))

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, dp(8))
        }
        val label = TextView(this).apply {
            text = "مكتبة الأنمي"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        row.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
        val refresh = TextView(this).apply {
            text = "تحديث"
            textSize = 14f
            setTextColor(accent)
            setPadding(dp(12), dp(8), dp(4), dp(8))
            setOnClickListener {
                anime.clear()
                loadCatalogPage(1)
            }
        }
        row.addView(refresh)
        root.addView(row)

        loading = TextView(this).apply {
            text = "جارٍ تحميل مكتبة الأنمي..."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, dp(24))
        }
        root.addView(loading)

        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val footer = TextView(this).apply {
            text = "مصدر بيانات العناوين والحلقات: Anime3rb"
            textSize = 11f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(4))
        }
        root.addView(footer)
        setContentView(root)
    }

    private fun setupHiddenCatalog() {
        hiddenCatalog = WebView(this)
        hiddenCatalog.visibility = View.GONE
        hiddenCatalog.settings.javaScriptEnabled = true
        hiddenCatalog.settings.domStorageEnabled = true
        hiddenCatalog.addJavascriptInterface(CatalogBridge(), "AnimeBridge")
        hiddenCatalog.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                val script = if (catalogMode == "anime") {
                    """
                    (function(){
                      const out=[];
                      document.querySelectorAll('a[href*="/titles/"]').forEach(a=>{
                        const u=new URL(a.href,location.href);
                        const t=(a.innerText||a.getAttribute('title')||'').trim().replace(/\s+/g,' ');
                        if(t && /^\/titles\/[a-z0-9-]+\/?$/i.test(u.pathname) && !u.pathname.includes('/list/'))
                          out.push({title:t,url:u.href});
                      });
                      AnimeBridge.receive(JSON.stringify(out));
                    })();
                    """
                } else {
                    """
                    (function(){
                      const out=[];
                      document.querySelectorAll('a[href*="/episode/"]').forEach(a=>{
                        const u=new URL(a.href,location.href);
                        const t=(a.innerText||a.getAttribute('title')||'').trim().replace(/\s+/g,' ');
                        if(t && u.hostname==='anime3rb.com') out.push({title:t,url:u.href});
                      });
                      AnimeBridge.receive(JSON.stringify(out));
                    })();
                    """
                }
                view.evaluateJavascript(script, null)
            }
        }
    }

    private fun loadCatalogPage(page: Int) {
        catalogMode = "anime"
        catalogPage = page
        loading?.visibility = View.VISIBLE
        loading?.text = "جارٍ تحميل مكتبة الأنمي ($page/$maxCatalogPages)..."
        hiddenCatalog.loadUrl(if (page == 1) "https://anime3rb.com/titles/list" else "https://anime3rb.com/titles/list?page=$page")
    }

    private inner class CatalogBridge {
        @JavascriptInterface
        fun receive(json: String) {
            runOnUiThread {
                try {
                    val arr = JSONArray(json)
                    if (catalogMode == "anime") {
                        for (i in 0 until arr.length()) {
                            val o = arr.getJSONObject(i)
                            val t = o.optString("title").trim()
                            val u = o.optString("url").trim()
                            if (t.isNotBlank() && u.startsWith("https://anime3rb.com/titles/") &&
                                anime.none { it.url == u }) anime.add(Entry(t, u))
                        }
                        if (catalogPage < maxCatalogPages) {
                            loadCatalogPage(catalogPage + 1)
                        } else {
                            loading?.visibility = View.GONE
                            renderAnime(search.text.toString())
                        }
                    } else {
                        episodes.clear()
                        for (i in 0 until arr.length()) {
                            val o = arr.getJSONObject(i)
                            val t = o.optString("title").trim()
                            val u = o.optString("url").trim()
                            if (t.isNotBlank() && u.contains("anime3rb.com/episode/") &&
                                episodes.none { it.url == u }) episodes.add(Entry(t, u))
                        }
                        showEpisodeList()
                    }
                } catch (_: Exception) {
                    loading?.visibility = View.VISIBLE
                    loading?.text = "تعذر قراءة البيانات من الموقع. حاول التحديث."
                }
            }
        }
    }

    private fun renderAnime(query: String) {
        if (!::list.isInitialized || screen != "home") return
        list.removeAllViews()
        val found = anime.filter { it.title.contains(query, ignoreCase = true) }
        found.forEach { item ->
            addCard(item.title) { openAnime(item) }
        }
        if (anime.isNotEmpty() && found.isEmpty()) {
            addMessage("لا توجد نتائج. جرّب كتابة الاسم بالإنجليزية أو جزء منه.")
        }
    }

    private fun addCard(text: String, action: () -> Unit) {
        val card = TextView(this).apply {
            this.text = text
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(dp(16), dp(17), dp(16), dp(17))
            background = rounded(panel, 14)
            setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(9)
        list.addView(card, lp)
    }

    private fun addMessage(text: String) {
        list.addView(TextView(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(24), dp(12), dp(24))
        })
    }

    private fun openAnime(item: Entry) {
        screen = "anime"
        currentAnime = item.title
        titleBar.text = "‹  $currentAnime"
        titleBar.setOnClickListener { returnHome() }
        search.visibility = View.GONE
        list.removeAllViews()
        loading?.visibility = View.VISIBLE
        loading?.text = "جارٍ تحميل الحلقات..."
        catalogMode = "episodes"
        hiddenCatalog.loadUrl(item.url)
        renderEpisodeLoading()
    }

    private fun renderEpisodeLoading() {
        list.removeAllViews()
        addMessage("جارٍ جلب قائمة الحلقات...")
    }

    private fun showEpisodeList() {
        screen = "anime"
        titleBar.text = "‹  $currentAnime"
        titleBar.setOnClickListener { returnHome() }
        loading?.visibility = View.GONE
        list.removeAllViews()
        if (episodes.isEmpty()) {
            addMessage("لم أجد حلقات في صفحة هذا الأنمي.")
        } else {
            episodes.forEach { ep -> addCard(ep.title.ifBlank { "فتح الحلقة" }) { playEpisode(ep.url) } }
        }
    }

    private fun returnHome() {
        if (::player.isInitialized) {
            player.stopLoading()
            player.destroy()
        }
        screen = "home"
        titleBar.text = "Anime3rb"
        titleBar.setOnClickListener(null)
        search.visibility = View.VISIBLE
        setContentView(root)
        renderAnime(search.text.toString())
    }

    private fun playEpisode(url: String) {
        screen = "player"
        player = WebView(this)
        player.settings.javaScriptEnabled = true
        player.settings.domStorageEnabled = true
        player.settings.mediaPlaybackRequiresUserGesture = false
        player.settings.javaScriptCanOpenWindowsAutomatically = false
        player.settings.setSupportMultipleWindows(false)
        player.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean {
                return false
            }
        }
        player.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                val host = uri.host?.lowercase().orEmpty()
                val scheme = uri.scheme?.lowercase().orEmpty()
                if (scheme == "https" && (host == "anime3rb.com" || host.endsWith(".anime3rb.com"))) return false
                // Keep ad redirects and unrelated top-level pages out of the app.
                return true
            }

            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val host = request.url.host?.lowercase().orEmpty()
                val blocked = listOf("madurird.com", "reowihep.com")
                if (blocked.any { host == it || host.endsWith(".$it") }) {
                    return WebResourceResponse("text/plain", "utf-8", 204, "No Content", emptyMap(), java.io.ByteArrayInputStream(ByteArray(0)))
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun onPageFinished(view: WebView, url: String) {
                view.evaluateJavascript("""
                    (function(){
                      try {
                        window.open = function(){ return null; };
                        document.querySelectorAll('a[target="_blank"]').forEach(a=>a.removeAttribute('target'));
                        document.addEventListener('click', function(e) {
                          const a=e.target.closest && e.target.closest('a');
                          if(a && a.href) {
                            try { if(new URL(a.href).origin !== location.origin) { e.preventDefault(); e.stopImmediatePropagation(); } } catch(_) {}
                          }
                        }, true);
                      } catch(_) {}
                    })();
                """.trimIndent(), null)
            }
        }
        setContentView(player)
        player.loadUrl(url)
    }

    override fun onBackPressed() {
        when (screen) {
            "player" -> showEpisodeList()
            "anime" -> returnHome()
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() {
        if (::hiddenCatalog.isInitialized) hiddenCatalog.destroy()
        if (::player.isInitialized) player.destroy()
        super.onDestroy()
    }
}
