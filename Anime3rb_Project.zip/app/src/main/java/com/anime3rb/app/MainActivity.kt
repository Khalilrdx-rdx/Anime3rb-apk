package com.anime3rb.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.content.Intent
import android.content.ActivityNotFoundException
import android.net.Uri
import android.webkit.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private val bg = Color.rgb(20, 27, 40)
    private val panel = Color.rgb(35, 45, 62)
    private val accent = Color.rgb(125, 190, 85)
    private lateinit var root: LinearLayout
    private lateinit var search: EditText
    private lateinit var list: LinearLayout
    private lateinit var catalogWeb: WebView
    private lateinit var episodeWeb: WebView
    private val episodes = mutableListOf<Pair<String, String>>()
    private var showingEpisode = false
    private var loadingLabel: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildHome()
        loadCatalog()
    }

    private fun buildHome() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            layoutParams = ViewGroup.LayoutParams(-1, -1)
            setPadding(dp(16), dp(12), dp(16), dp(8))
        }
        val header = TextView(this).apply {
            text = "Anime3rb"
            textSize = 26f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(12))
        }
        root.addView(header)

        search = EditText(this).apply {
            hint = "ابحث في الحلقات الظاهرة..."
            textSize = 15f
            singleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            setPadding(dp(14), 0, dp(14), 0)
            background = rounded(panel, 14)
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderEpisodes(s?.toString().orEmpty()) }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(50)))

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, dp(8))
        }
        val label = TextView(this).apply {
            text = "أحدث الحلقات"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        row.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
        val refresh = TextView(this).apply {
            text = "تحديث"
            textSize = 14f
            setTextColor(accent)
            setPadding(dp(12), dp(8), dp(4), dp(8))
            setOnClickListener { loadCatalog() }
        }
        row.addView(refresh)
        root.addView(row)

        loadingLabel = TextView(this).apply {
            text = "جارٍ تحميل قائمة الحلقات..."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, dp(24))
        }
        root.addView(loadingLabel)

        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val footer = TextView(this).apply {
            text = "مصدر بيانات الحلقات: Anime3rb"
            textSize = 11f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(4))
        }
        root.addView(footer)
        setContentView(root)
    }

    private fun loadCatalog() {
        episodes.clear()
        loadingLabel?.visibility = View.VISIBLE
        loadingLabel?.text = "جارٍ تحميل أحدث الحلقات..."
        if (!::catalogWeb.isInitialized) {
            catalogWeb = WebView(this)
            catalogWeb.settings.javaScriptEnabled = true
            catalogWeb.settings.domStorageEnabled = true
            catalogWeb.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    val js = """
                        (function() {
                          const items = [];
                          document.querySelectorAll('a[href*="/episode/"]').forEach(a => {
                            const title = (a.innerText || a.getAttribute('title') || '').trim().replace(/\s+/g, ' ');
                            const href = a.href || '';
                            if (title && href.startsWith('https://anime3rb.com/episode/')) {
                              items.push({title: title, url: href});
                            }
                          });
                          AndroidCatalog.receive(JSON.stringify(items));
                        })();
                    """.trimIndent()
                    view.evaluateJavascript(js, null)
                }
            }
            catalogWeb.addJavascriptInterface(CatalogBridge(), "AndroidCatalog")
            root.addView(catalogWeb, LinearLayout.LayoutParams(1, 1))
            catalogWeb.alpha = 0f
        }
        catalogWeb.loadUrl("https://anime3rb.com/")
    }

    private inner class CatalogBridge {
        @JavascriptInterface
        fun receive(json: String) {
            runOnUiThread {
                try {
                    val arr = JSONArray(json)
                    episodes.clear()
                    for (i in 0 until arr.length()) {
                        val item = arr.getJSONObject(i)
                        val title = item.optString("title").trim()
                        val url = item.optString("url").trim()
                        if (title.isNotBlank() && url.startsWith("https://anime3rb.com/episode/")) {
                            if (episodes.none { it.second == url }) episodes.add(title to url)
                        }
                    }
                    loadingLabel?.visibility = View.GONE
                    if (episodes.isEmpty()) {
                        loadingLabel?.visibility = View.VISIBLE
                        loadingLabel?.text = "لم تصل قائمة الحلقات. قد يمنع الموقع التحميل الآلي؛ جرّب التحديث أو افتح الموقع من المتصفح."
                    }
                    renderEpisodes(search.text.toString())
                } catch (_: Exception) {
                    loadingLabel?.visibility = View.VISIBLE
                    loadingLabel?.text = "تعذر قراءة قائمة الحلقات من الموقع."
                }
            }
        }
    }

    private fun renderEpisodes(filter: String) {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val filtered = episodes.filter { it.first.contains(filter, ignoreCase = true) }
        for ((title, url) in filtered) {
            val card = TextView(this).apply {
                text = title
                textSize = 15f
                setTextColor(Color.WHITE)
                setPadding(dp(16), dp(17), dp(16), dp(17))
                background = rounded(panel, 14)
                setOnClickListener { openEpisode(url) }
            }
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = dp(9)
            list.addView(card, lp)
        }
        if (episodes.isNotEmpty() && filtered.isEmpty()) {
            val empty = TextView(this).apply {
                text = "لا توجد نتائج مطابقة."
                setTextColor(Color.LTGRAY)
                gravity = Gravity.CENTER
                setPadding(0, dp(24), 0, dp(24))
            }
            list.addView(empty)
        }
    }

    private fun openEpisode(url: String) {
        showingEpisode = true
        episodeWeb = WebView(this)
        episodeWeb.settings.javaScriptEnabled = true
        episodeWeb.settings.domStorageEnabled = true
        episodeWeb.settings.mediaPlaybackRequiresUserGesture = false
        episodeWeb.settings.javaScriptCanOpenWindowsAutomatically = true
        episodeWeb.webChromeClient = WebChromeClient()
        episodeWeb.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                handleExternalUrl(request.url.toString())
            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean = handleExternalUrl(url)
        }
        setContentView(episodeWeb)
        episodeWeb.loadUrl(url)
    }

    private fun handleExternalUrl(url: String): Boolean {
        val uri = Uri.parse(url)
        val scheme = uri.scheme?.lowercase()
        if (scheme == "https" || scheme == "http") return false
        if (scheme == "intent") {
            try {
                val intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME).apply {
                    addCategory(Intent.CATEGORY_BROWSABLE)
                    component = null
                }
                try {
                    startActivity(intent)
                } catch (_: ActivityNotFoundException) {
                    val fallback = intent.getStringExtra("browser_fallback_url")
                    if (!fallback.isNullOrBlank()) episodeWeb.loadUrl(fallback)
                }
            } catch (_: Exception) {}
            return true
        }
        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) {}
        return true
    }

    override fun onBackPressed() {
        if (showingEpisode) {
            showingEpisode = false
            if (::episodeWeb.isInitialized) episodeWeb.destroy()
            setContentView(root)
        } else {
            super.onBackPressed()
        }
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
